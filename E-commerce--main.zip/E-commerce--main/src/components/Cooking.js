const Cooking =[
    {
        img: "https://m.media-amazon.com/images/I/614tne6K3VL._AC_UL400_.jpg",
        name: "Saffola Honey Active",
        kilogram: "1000",
        rupee: "258",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61anM5yafSL._AC_UL400_.jpg",
        name: "Sugarfree Natura Low Calorie Sweetner",
        kilogram: "100",
        rupee: "135",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/91SWDnldaaL._AC_UL400_.jpg",
        name: "Aashirvaad Atta with Multigrains, 5kg",
        kilogram: "5000",
        rupee: "310",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/815FybCip8L._AC_UL400_.jpg",
        name: "Vedaka Medium Poha",
        kilogram: "500",
        rupee: "35",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81sAa2fovtS._AC_UL400_.jpg",
        name: "Dabur Honey",
        kilogram: "400",
        rupee: "192",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/51nrRPo4yxL._AC_UL400_.jpg",
        name: "Del Monte Tomato Ketchup",
        kilogram: "950",
        rupee: "90",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/91UAbhAwkwL._AC_UL400_.jpg",
        name: "MAGGI Masala-ae-Magic Vegetable Masala",
        kilogram: "72",
        rupee: "60",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61YroxhurlL._AC_UL400_.jpg",
        name: "Catch Sprinkles Chat Masala",
        kilogram: "100",
        rupee: "72",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61BIMMR07KL._AC_UL400_.jpg",
        name: "Kissan Fresh Tomato Ketchup",
        kilogram: "2000",
        rupee: "230",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61aejDf4RML._AC_UL400_.jpg",
        name: "Tata Sampann White Thin Poha",
        kilogram: "500",
        rupee: "54",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61n0dwj9qdL._AC_UL400_.jpg",
        name: "Pillsbury Butterscotch Flavour Pancake Mix",
        kilogram: "400",
        rupee: "166",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81+FF+RsymL._AC_UL400_.jpg",
        name: "Aashirvaad Superior MP Atta",
        kilogram: "5000",
        rupee: "295",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/51peVGrUwEL._AC_UL400_.jpg",
        name: "True Elements Quinoa 1kg",
        kilogram: "1000",
        rupee: "260",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/91aCyFGW5eL._AC_UL400_.jpg",
        name: "Aashirvaad Natures Superfoods Ragi Flour",
        kilogram: "1000",
        rupee: "77",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71X+spg1nzL._AC_UL400_.jpg",
        name: "Betty Crocker Complete Classic Pancake Mix",
        kilogram: "500",
        rupee: "188",
        orderquantity: 0
    }
]

export default Cooking;