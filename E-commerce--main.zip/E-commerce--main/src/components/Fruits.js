const Fruits = [
    {
        img: "https://m.media-amazon.com/images/I/81aRkv2DltL._AC_UL400_.jpg",
        name: "Apple Red Delicious",
        kilogram: "500",
        rupee: "100",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81AK2aQ8VvL._AC_UL400_.jpg",
        name: "Apple Royal Gala",
        kilogram: "500",
        rupee: "90",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/41YYLKLwOFL._AC_UL400_.jpg",
        name: "Peer Green",
        kilogram: "250",
        rupee: "50",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/611a1wD9ZGL._AC_UL400_.jpg",
        name: "Pomegranate",
        kilogram: "500",
        rupee: "110",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71GsHTwUwaL._AC_UL400_.jpg",
        name: "Dragon Fruit",
        kilogram: "250",
        rupee: "100",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/41LwnkECZ2L._AC_UL400_.jpg",
        name: "Orange",
        kilogram: "500",
        rupee: "70",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/51XNfdOEEgL._AC_UL400_.jpg",
        name: "Mango",
        kilogram: "1000",
        rupee: "52",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/41Y2eoT3OTL._AC_UL400_.jpg",
        name: "Banana Yelakki",
        kilogram: "500",
        rupee: "44",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/41BT6B8l3qL._AC_UL400_.jpg",
        name: "Banana Sevvala",
        kilogram: "500",
        rupee: "45",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/31dAakZ+ztL._AC_UL400_.jpg",
        name: "Banana Nendran",
        kilogram: "500",
        rupee: "36",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/51qc+x0iSpL._AC_UL400_.jpg",
        name: "Figs",
        kilogram: "250",
        rupee: "46",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/41hHYouepyL._AC_UL400_.jpg",
        name: "Tomato - Cherry",
        kilogram: "250",
        rupee: "23",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71ptno4aB1L._AC_UL400_.jpg",
        name: "Lemon",
        kilogram: "250",
        rupee: "48",
        orderquantity: 0
    }
]

export default Fruits;