const DryFruits = [
    {
        img: "https://m.media-amazon.com/images/I/61ZOa9aqbYL._AC_UL400_.jpg",
        name: "Tata nuts mix",
        kilogram: "200",
        rupee: "243",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/713D1eLsaqL._AC_UL400_.jpg",
        name: "Happilo Dried Almonds",
        kilogram: "400",
        rupee: "409",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61Zg9Z1I1cL._AC_UL400_.jpg",
        name: "Dry Fruits Powder",
        kilogram: "600",
        rupee: "300",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81VCzv0k+CL._AC_UL400_.jpg",
        name: "Rostaa Dried Cranberry",
        kilogram: "200",
        rupee: "225",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71wN3yZF77L._AC_UL400_.jpg",
        name: "Happilo Black Raisins",
        kilogram: "250",
        rupee: "148",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61fy6IX+jTL._AC_UL400_.jpg",
        name: "Tata Cashews Whole",
        kilogram: "500",
        rupee: "509",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/613-acgg8yL._AC_UL400_.jpg",
        name: "Nutty Gritties Dried Plums",
        kilogram: "200",
        rupee: "239",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71rl4c7G4mL._AC_UL400_.jpg",
        name: "Naturoz Dry Dates 500g",
        kilogram: "500",
        rupee: "160",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71rl4c7G4mL._AC_UL400_.jpg",
        name: "Happilo Inshell Raw Walnut Kernels 500g",
        kilogram: "500",
        rupee: "331",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71Yxp0Mn-xL._AC_UL400_.jpg",
        name: "Nutty Gritties Mix Berries Dried Berry 200g",
        kilogram: "200",
        rupee: "325",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81EGKq5bdGL._AC_UL400_.jpg",
        name: "Tulsi Walnuts Kernels,200g,Raw",
        kilogram: "200",
        rupee: "289",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/41I9WoMIs3L._AC_UL400_.jpg",
        name: "Nature Prime Mixed Dry Fruits and Nuts 500gm",
        kilogram: "500",
        rupee: "399",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71lmddoIdNL._AC_UL400_.jpg",
        name: "Nuts About You RAISIN, 500 g",
        kilogram: "500",
        rupee: "149",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71P2iOAIi9L._AC_UL400_.jpg",
        name: "Happilo Whole Cashews 1 kg",
        kilogram: "1000",
        rupee: "1007",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71e4EA+-ILL._AC_UL400_.jpg",
        name: "GreenFinity Combo (Almonds, Cashews, Raisin, Roasted Pistachio)",
        kilogram: "1000",
        rupee: "998",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81a6JguUiEL._AC_UL400_.jpg",
        name: "Rostaa Turkish Golden Apricot Dried 200g",
        kilogram: "200",
        rupee: "234",
        orderquantity: 0
    }
]

export default DryFruits;