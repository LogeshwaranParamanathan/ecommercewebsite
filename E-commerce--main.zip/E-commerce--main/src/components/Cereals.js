const Cereals = [
    {
        img: "https://m.media-amazon.com/images/I/91i9rdecBvL._AC_UL400_.jpg",
        name: "Kellogg's Muesli",
        kilogram: "750",
        rupee: "360",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81mBSoS6ibL._AC_UL400_.jpg",
        name: "Bagrry's Corn Flakes Plus",
        kilogram: "800",
        rupee: "189",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81sroBghi-L._AC_UL400_.jpg",
        name: "Solimo - Cranberry Muesli",
        kilogram: "1000",
        rupee: "335",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81mG4m+EUUL._AC_UL400_.jpg",
        name: "Kelloggs Froot Loops",
        kilogram: "285",
        rupee: "169",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71ddUpQHXRL._AC_UL400_.jpg",
        name: "Kelloggs All Bran Wheat Flakes",
        kilogram: "440",
        rupee: "242",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81AToCjQ48L._AC_UL400_.jpg",
        name: "Kelloggs Corn Flakes",
        kilogram: "1000",
        rupee: "525",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71d0wtpbxJL._AC_UL400_.jpg",
        name: "Quaker Oats ",
        kilogram: "1000",
        rupee: "174",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71k6Fkb4htL._AC_UL400_.jpg",
        name: "Saffola Oats",
        kilogram: "1000",
        rupee: "154",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61afic8TVmL._AC_UL400_.jpg",
        name: "Kelloggs Oats",
        kilogram: "2000",
        rupee: "290",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81UQmamxlWL._AC_UL400_.jpg",
        name: "Protinex Health And Nutritional Protein Drink Mix For Adults",
        kilogram: "400",
        rupee: "570",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/61sJ0eQON1L._AC_UL400_.jpg",
        name: "True Elements Muesli Fruit and Nuts",
        kilogram: "1000",
        rupee: "509",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/611SEyUragL._AC_UL400_.jpg",
        name: "True Elements Whole Oatmeal 1kg",
        kilogram: "1000",
        rupee: "486",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/81MY+9QmjBL._AC_UL400_.jpg",
        name: "Kellogg's Cornflakes Real Honey 300g ",
        kilogram: "300",
        rupee: "170",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/713UmwZL8mL._AC_UL400_.jpg",
        name: "Tata Soulfull Millet Muesli | Fruit & Nut",
        kilogram: "1000",
        rupee: "424",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71Qast1ngHL._AC_UL400_.jpg",
        name: "Kellogg's Corn Flakes with Real Strawberry Puree",
        kilogram: "575",
        rupee: "315",
        orderquantity: 0
    },
    {
        img: "https://m.media-amazon.com/images/I/71V3bjbvYKL._AC_UL400_.jpg",
        name: "Quaker Oats",
        kilogram: "400",
        rupee: "79",
        orderquantity: 0
    }
]

export default Cereals;