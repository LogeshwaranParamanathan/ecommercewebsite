const Vegetables = [
    {
      img: "https://m.media-amazon.com/images/I/41L46kSwk7L._AC_UL320_.jpg",
      name: "Tomato",
      kilogram: "250",
      rupee: "20",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/51v2ozMXy8L._AC_UL320_.jpg",
      name: "Onion",
      kilogram: "250",
      rupee: "15",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/313dtY-LOEL._AC_UL320_.jpg",
      name: "Potato",
      kilogram: "200",
      rupee: "10",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/71pbtRs3UQL._AC_UL320_.jpg",
      name: "Coriander",
      kilogram: "100",
      rupee: "10",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/61SCxbFGpWL._AC_UL320_.jpg",
      name: "Ginger",
      kilogram: "100",
      rupee: "9",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/710TY8GGGqL._AC_UL320_.jpg",
      name: "Beet Root",
      kilogram: "250",
      rupee: "11",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/81dnQAFzn-L._AC_UL320_.jpg",
      name: "Chilli-Green",
      kilogram: "100",
      rupee: "5",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/51BomV2ZiaL._AC_UL320_.jpg",
      name: "Cauliflower",
      kilogram: "500",
      rupee: "24",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/71ZaS7W9dYL._AC_UL320_.jpg",
      name: "Water Melon",
      kilogram: "1",
      rupee: "62",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/71J4gpncRhL._AC_UL320_.jpg",
      name: "Spinach",
      kilogram: "250",
      rupee: "29",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/51yvxGKCiYL._AC_UL320_.jpg",
      name: "Bhendi",
      kilogram: "500",
      rupee: "29",
      orderquantity: 0
    },
    {
      img: "https://m.media-amazon.com/images/I/311P1uv0ikL._AC_UL320_.jpg",
      name: "Carrot",
      kilogram: "500",
      rupee: "15",
      orderquantity: 0
    },
  ]

  export default Vegetables;